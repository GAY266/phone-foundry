# PHONE FOUNDRY

Классическая структура GitHub-репозитория: HTML-игра в корне, `LICENSE` и workflow `build-apk.yml`.

## Сборка APK
1. Загрузите все файлы репозитория на GitHub, включая скрытую папку `.github`.
2. Откройте вкладку **Actions**.
3. Запустите workflow **Build APK** или дождитесь запуска после push.
4. Откройте завершённый запуск и скачайте artifact **build-apk**.
5. Распакуйте artifact ZIP: внутри находится `app-debug.apk`.

Игра встраивается в APK локально из `phone_foundry.html`, поэтому интернет не нужен для загрузки самой игры.

`LICENSE` — MIT. Это debug APK для установки вручную, не готовая публикация в Google Play.


### PHONE FOUNDRY 1.1.01 — Camera dropdowns
- Camera megapixels, aperture, sensor size, and sensor model are selected from dropdown lists for main, ultrawide, and telephoto cameras.
- This release does not yet restrict camera choices by the in-game year.
