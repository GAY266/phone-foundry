# PHONE FOUNDRY mod format

Select a mod in the in-game MODS screen before creating a company. Import `.json` or `.it` files manually.

## JSON example
```json
{
  "name": "Example Mod",
  "description": "A custom starting economy",
  "cashMultiplier": 2.5,
  "startYear": 2017,
  "marketMultiplier": 0.9,
  "difficulty": "normal"
}
```

Allowed difficulty values: `easy`, `normal`, `hard`. `cashMultiplier` must be between 0.1 and 100; `startYear` from 2000 to 2100; `marketMultiplier` from 0.1 to 5.

## Simple IT example (`difficulty.it`)
```
name = "Retro Challenge";
description = "Start in 2017 with a tougher market";
cashMultiplier = 1.25;
startYear = 2017;
marketMultiplier = 0.8;
difficulty = hard;
```

This is a simple key/value IT format, not Haxe. The browser cannot scan Android's hidden `.mods` directory automatically; use the import button.
