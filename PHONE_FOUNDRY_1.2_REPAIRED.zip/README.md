# PHONE FOUNDRY

Классическая структура GitHub-репозитория: HTML-игра в корне, `LICENSE` и workflow `build-apk.yml`.

## Сборка APK
1. Загрузите все файлы репозитория на GitHub, включая скрытую папку `.github`.
2. Откройте вкладку **Actions**.
3. Запустите workflow **Build APK** или дождитесь запуска после push.
4. Откройте завершённый запуск и скачайте artifact **PHONE-FOUNDRY-APK**.
5. Распакуйте artifact ZIP: внутри находится `app-debug.apk`.

Игра встраивается в APK локально из `phone_foundry.html`, поэтому интернет не нужен для загрузки самой игры.

`LICENSE` — MIT. Это debug APK для установки вручную, не готовая публикация в Google Play.


### PHONE FOUNDRY 1.1.01 — Camera dropdowns
- Camera megapixels, aperture, sensor size, and sensor model are selected from dropdown lists for main, ultrawide, and telephoto cameras.
- This release does not yet restrict camera choices by the in-game year.


## Version 1.2
See `LOG.md` for the video settings and year-aware review updates. The ZIP contains source files; an APK has not been built or tested.


## PHONE FOUNDRY 1.2 — Mods
Перед созданием компании выберите мод в разделе «МОДЫ». Для пользовательского мода импортируйте `.json` или `.it` файл. Формат и примеры находятся в `mods/`. В браузерной версии нельзя автоматически читать скрытую папку Android, поэтому файл выбирается вручную.
