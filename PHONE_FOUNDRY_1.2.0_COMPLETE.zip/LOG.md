# PHONE FOUNDRY 1.2.0 — Complete Edition

## 🇷🇺 Что нового
- Объединены настройки видеосъёмки: качество, FPS и замедленная съёмка.
- Локальная генерация игровых отзывов по характеристикам и году выпуска.
- Окно «МОДЫ» перед созданием компании; выбор встроенного мода или импорт пользовательского JSON/IT.
- Добавлено производство партиями с расчётом затрат и ограничением по доступным средствам.
- Добавлена новостная лента рынка.
- Добавлены переговоры о технологическом партнёрстве, покупке компаний и вступлении в статус суббренда.
- Добавлена система суббрендов и попытка восстановления независимости при выполнении условий.

## 🇬🇧 What's New
- Combined video settings: quality, FPS, and slow motion.
- Local rule-based generation of in-game reviews based on device specs and release year.
- A Mods screen before company creation, with built-in choices and JSON/IT import.
- Batch production with cost calculation and available-cash limits.
- Added a market news feed.
- Added negotiations for technology partnerships, company acquisitions, and sub-brand status.
- Added sub-brand status and an independence attempt with requirements.

Note: source ZIP only; APK build and full-device testing have not been performed.
